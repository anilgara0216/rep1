package org.gor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GorApplicationTests {

	@Test
	void contextLoads() {
	}

}
