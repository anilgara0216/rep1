package org.gor.person.controllers;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/public")
public class PublicController {
	
	
	@GetMapping("/all")
	public String getMsgFromAll() {
		return "All";
	}
	
	
	
	@GetMapping("/admin")
	public String getMsgFromAdmin() {
		return "Admin";
	}
	
	
	
	
	@GetMapping("/user")
	public String getMsgFromUser() {
		return "User";
	}
}
