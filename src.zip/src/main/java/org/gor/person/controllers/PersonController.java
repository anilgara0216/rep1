package org.gor.person.controllers;

import java.util.List;

import org.gor.person.entity.Person;
import org.gor.person.service.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
//@RequestMapping("/")
public class PersonController {
	
	@Autowired
	PersonService personService;
	
	
	@PostMapping("person")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	ResponseEntity<Person> addPerson(@RequestBody Person person ){		
		Person savedPerson = personService.addPerson(person);		
		return new ResponseEntity<Person> (savedPerson, HttpStatus.OK);		
	}
	
	@PreAuthorize("hasAuthority('ROLE_USER')")
	@GetMapping("person/{id}")
	ResponseEntity<Person> getPerson(@PathVariable("id") long id) {
		Person person = personService.getPerson(id);
		return new ResponseEntity<Person> (person, HttpStatus.OK); 
	}
	
	@GetMapping("persons")
	ResponseEntity<List<Person>> getPersons(){
		List<Person> persons = personService.getPersons();
		return new ResponseEntity<List<Person>> (persons, HttpStatus.OK);
	}
	
	@PutMapping("person")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	ResponseEntity<Person> updatePerson(@RequestBody Person person) {
		Person updatedPerson =  personService.updatePerson(person);
		return new ResponseEntity<Person>(updatedPerson, HttpStatus.OK);
	}
	
	@DeleteMapping("person/{id}")
	@PreAuthorize("hasAuthority('ROLE_ADMIN')")
	ResponseEntity<Person> deletePerson(@PathVariable long id){
		Person deletedPerson = personService.deletePerson(id);
		return new ResponseEntity<Person> (deletedPerson, HttpStatus.OK);
	}	
}
