package org.gor.person.entity;

import java.io.Serializable;
import java.util.Date;



import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;


import lombok.Data;

@Data
@Entity
public class Person implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	long personId;
	String name;
	Date dob;
	String aadhar;
	String pan;
	String email;
	String phone;
	String mobile;
	String address;
	

}
