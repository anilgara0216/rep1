package org.gor.person.service;

import java.util.List;
import java.util.Optional;

import org.gor.person.entity.Person;
import org.gor.person.repository.PersonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonService {
	
	@Autowired
	PersonRepository personRepository; 
	
	public Person addPerson(Person person) {
		return personRepository.save(person);		
	}
	
	public Person getPerson(long personId) {
		Optional<Person> personOpt = personRepository.findById(personId);
		if (personOpt.isPresent()) {
			return personOpt.get();
		} else {
			//throw new Exception("Person not found. Person Id:" + personId);
			return null;
		}
	}
	
	public List<Person> getPersons() {
		return personRepository.findAll();
	}
	
	
	public Person updatePerson(Person person) {		
		Optional<Person> personOpt = personRepository.findById(person.getPersonId());
		if (personOpt.isPresent()) {
			Person updatedPerson = personRepository.save(person);
			return updatedPerson;
		} else {
			//throw new Exception("Person not found. Person Id:" + personId);
			return null;
		}		
	}
	
	
	public Person deletePerson(long personId) {
		Optional<Person> personOpt = personRepository.findById(personId);
		if (personOpt.isPresent()) {
			personRepository.deleteById(personId);
			return personOpt.get();
		} else {
			//throw new Exception("Person not found. Person Id:" + personId);
			return null;
		}		
	}

}
