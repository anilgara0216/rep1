package org.gor.user.service;

import java.security.Key;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtTokenService {
	
	public static final String  SECRET = "442A472D4A614E645267556B58703273357638792F423F4528482B4D62506553";
	
	public String extractUsername(String token) {		
		return extractClaim(token, Claims::getSubject);
	}
	
	
	public <T> T extractClaim(String token, Function<Claims, T> claimResolver) {
		Claims claims = extractAllClaims(token);
		return claimResolver.apply(claims);
	}
	
	private Claims extractAllClaims(String token) {
		return Jwts.parserBuilder()
		.setSigningKey(getSignKey())
		.build()
		.parseClaimsJws(token)
		.getBody();
	}


	
	
	public String generateToken(String username) {		
		Map<String, Object> claims = new HashMap<>();
		return createToken(claims, username);
	}
	public Date extractExpiration(String token) {
        return extractClaim(token, Claims::getExpiration);
    }

	private String createToken(Map<String, Object> claims, String username) {
		return Jwts.builder()
				.setClaims(claims)
				.setSubject(username)
				.setIssuedAt(new Date(System.currentTimeMillis()))
				//.setExpiration(new Date(System.currentTimeMillis()+1000*60*5)) //5 min
				.setExpiration(new Date(System.currentTimeMillis()+1000*60*15)) // 15 min
				.signWith(getSignKey(), SignatureAlgorithm.HS256)
				.compact();
	}

	private Key getSignKey() {
		byte[] keyBytes = Decoders.BASE64.decode(SECRET);
		return Keys.hmacShaKeyFor(keyBytes);
	}


	private Boolean isTokenExpired(String token) {
        return extractExpiration(token).before(new Date());
    }
	public boolean validateToken(String token, UserDetails userDetails) {
		final String username = extractUsername(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
	}

}
