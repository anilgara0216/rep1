package org.gor.user.service;

import java.util.List;
import java.util.Optional;

import org.gor.user.entity.User;
import org.gor.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;
	
	@Autowired
	PasswordEncoder passwordEncoder;
	
	public User addUser(User user) {
		user.setPassword(passwordEncoder.encode(user.getPassword()));
		User addedUser = userRepository.save(user);
		return addedUser;		
	}
	
	public User updateUser(User user) {
		Optional<User> existingUserDataOpt = userRepository.findById(user.getUserId());
		if ( existingUserDataOpt.isPresent()) {
			User updatedUser = userRepository.save(user);
			return updatedUser;
		} else {
			throw new RuntimeException("User not found.");
		}
	}
	
	public User deleteUser(long userId) {
		Optional<User> existingUserDataOpt = userRepository.findById(userId);		
		if ( existingUserDataOpt.isPresent()) {
			User deletedUser = existingUserDataOpt.get();
			userRepository.deleteById(userId);
			return deletedUser;
		} else {
			throw new RuntimeException("User not found.");
		}		
	}
	
	
	public User getUser(long userId) {
		Optional<User> userOpt = userRepository.findById(userId);
		if(userOpt.isPresent()) {
			return userOpt.get();
		} else {
			throw new RuntimeException("User not found.");
		}
	}
	
	
	public List<User> getUsers() {
		return userRepository.findAll();		
	}

}
