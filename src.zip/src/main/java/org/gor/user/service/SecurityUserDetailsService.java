package org.gor.user.service;

import java.util.Optional;

import org.gor.user.dto.SecurityUserDetails;
import org.gor.user.entity.User;
import org.gor.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class SecurityUserDetailsService implements UserDetailsService {
	
	@Autowired
	UserRepository userRepository;	

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Optional<User>  userOpt =  userRepository.findByUsername(username);		
		return userOpt.map(SecurityUserDetails::new)
					  .orElseThrow(() -> new UsernameNotFoundException("user not found " + username));
		
	}
}
