package org.gor.user.controllers;

import java.util.List;
import java.util.Optional;

import org.gor.user.dto.AuthRequest;
import org.gor.user.entity.User;
import org.gor.user.service.JwtTokenService;
import org.gor.user.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@Autowired
	AuthenticationManager authenticationManager;
	
	
	@PostMapping()
	public ResponseEntity<?> addUser(@RequestBody User user) {
		User addedUser = userService.addUser(user);
		return new ResponseEntity<>(addedUser, HttpStatus.OK);		
	}
	
	@PutMapping()
	public ResponseEntity<?> updateUser(@RequestBody User user) {
		User updatedUser = userService.updateUser(user);
		return new ResponseEntity<>(updatedUser, HttpStatus.OK);		
	}
	
	@DeleteMapping()
	public ResponseEntity<?> deleteUser(@PathVariable long userId) {		
		User deletedUser = userService.deleteUser(userId);
		return new ResponseEntity<>(deletedUser, HttpStatus.OK);				
	}
	
	@GetMapping("/{userId}")
	public ResponseEntity<?> getUser(@PathVariable long userId) {
		User user = userService.getUser(userId);
		return new ResponseEntity<>(user, HttpStatus.OK);
	}
	
	@GetMapping("/all")
	public ResponseEntity<?> getUsers(){
		List<User> userList = userService.getUsers();
		return new ResponseEntity<>(userList, HttpStatus.OK);
	}
	
	@Autowired
	JwtTokenService jwtTokenService;
	
	@PostMapping("/authenticate")
	public String authenticateAndGetToken(@RequestBody AuthRequest authRequest ) {
		Authentication authentication = authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword()));
		if ( authentication.isAuthenticated()) {
			System.out.println("BBB");
			return jwtTokenService.generateToken(authRequest.getUsername());
		} else {
			System.out.println("CCC");
			throw new UsernameNotFoundException("Invalid user");
		}
		
		
		
		
	}

}
