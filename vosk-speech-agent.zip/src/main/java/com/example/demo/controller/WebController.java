package com.example.demo.controller;
import com.example.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class WebController {

    @Autowired
    SpeechService speechService;

    @Autowired
    ExcelService excelService;

    @GetMapping("/")
    public String home() {
        return "index";
    }

    @PostMapping("/start")
    public String start(Model model) {
        String text = speechService.recognize();
        excelService.save(text);
        model.addAttribute("msg", text);
        return "index";
    }
}
