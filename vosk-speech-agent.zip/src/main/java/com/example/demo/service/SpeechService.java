package com.example.demo.service;
import org.springframework.stereotype.Service;
import org.vosk.Model;
import org.vosk.Recognizer;

import javax.sound.sampled.*;

@Service
public class SpeechService {
    public String recognize() {
        try {
            Model model = new Model("C:/vosk-model");

            AudioFormat format = new AudioFormat(16000, 16, 1, true, false);
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            TargetDataLine mic = (TargetDataLine) AudioSystem.getLine(info);

            mic.open(format);
            mic.start();

            Recognizer recognizer = new Recognizer(model, 16000);
            byte[] buffer = new byte[4096];
            String result = "";

            long end = System.currentTimeMillis() + 5000;

            while (System.currentTimeMillis() < end) {
                int bytesRead = mic.read(buffer, 0, buffer.length);
                if (recognizer.acceptWaveForm(buffer, bytesRead)) {
                    result = recognizer.getResult();
                }
            }

            mic.stop();
            mic.close();

            recognizer.close();
            model.close();

            result = result.replaceAll(".*\"text\"\s*:\s*\"(.*?)\".*", "$1");

            return result;

        } catch (Exception e) {
            e.printStackTrace();
            return "Error in speech recognition";
        }
    }
}
