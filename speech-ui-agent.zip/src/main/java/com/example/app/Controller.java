package com.example.app;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
@RestController
public class Controller{
@Autowired ExcelService s;
@PostMapping("/save")
public String save(@RequestBody String text){s.save(text);return "saved";}
}