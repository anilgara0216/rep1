package com.example.app;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;
import java.io.*;import java.time.LocalDateTime;
@Service
public class ExcelService{
String FILE="SpeechLogs.xlsx";
public void save(String text){try{
File f=new File(FILE);Workbook wb;Sheet sh;
if(f.exists()){wb=new XSSFWorkbook(new FileInputStream(f));sh=wb.getSheetAt(0);}else{wb=new XSSFWorkbook();sh=wb.createSheet("Data");}
int r=sh.getLastRowNum()+1;Row row=sh.createRow(r);
LocalDateTime t=LocalDateTime.now();
row.createCell(0).setCellValue(t.toString());
row.createCell(1).setCellValue(text);
wb.write(new FileOutputStream(FILE));
}catch(Exception e){e.printStackTrace();}}
}