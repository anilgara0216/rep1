package com.example.SmartBankingAssistant.AIChatService.SmartBankingAssistantAI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartBankingAssistantAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
