package com.example.SmartBankingAssistant.Controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SmartBankingAssistant.Model.Transaction;
import com.example.SmartBankingAssistant.Service.TransactionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/transactions")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class TransactionController {
	@Autowired
    private TransactionService transactionService;
    
    
    @GetMapping("/{accountNumber}")
    public ResponseEntity<List<Transaction>> getTransactions(@PathVariable String accountNumber) {
        return ResponseEntity.ok(transactionService.getRecentTransaction(accountNumber));
    }

    @GetMapping("/{accountNumber}/expenses")
    public ResponseEntity<Map<String, BigDecimal>> getExpenses(@PathVariable String accountNumber) {
        return ResponseEntity.ok(transactionService.getExpenseSummary(accountNumber));
    }


}