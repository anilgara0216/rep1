package com.example.SmartBankingAssistant.Service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SmartBankingAssistant.Model.Account;
import com.example.SmartBankingAssistant.Repository.AccountRepository;

import lombok.RequiredArgsConstructor;

@Service
//Marks this class as a Spring Service component
//Spring will manage this class as a bean
@RequiredArgsConstructor
//Lombok annotation that generates a constructor
//for all final fields (dependency injection made easy)

public class AccountService {

	@Autowired
 private  AccountRepository accountRepository;

 public String getBalance(String accountNumber) {

     Optional<Account> optional =
             accountRepository.findByAccountNumber(accountNumber);

     if (optional.isPresent()) {
         Account acc = optional.get();
         return "Your current balance is ₹" + acc.getBalance()
                 + " in your " + acc.getAccountType() + " account.";
     }

     return "Account not found. Please check your account number.";
 }

 public Map<String, Object> getAccountDetails(String accountNumber) {

     Optional<Account> optional =
             accountRepository.findByAccountNumber(accountNumber);

     if (!optional.isPresent()) {
         throw new RuntimeException("Account not found");
     }

     Account acc = optional.get();

     Map<String, Object> map = new HashMap<>();
     map.put("accountNumber", acc.getAccountNumber());
     map.put("ownerName", acc.getOwnerName());
     map.put("balance", acc.getBalance());
     map.put("accountType", acc.getAccountType());

     return map;
 }
}