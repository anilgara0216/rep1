package com.example.SmartBankingAssistant.Service;



import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SmartBankingAssistant.Model.Transaction;
import com.example.SmartBankingAssistant.Repository.TransactionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class TransactionService {
	@Autowired
    private TransactionRepository transactionRepository;

    public List<Transaction> getRecentTransaction(String accountNumber){
        return transactionRepository.findByAccountNumberOrderByTimestampDesc(accountNumber)
                .stream().limit(10).collect(Collectors.toList());
    }

    //Expense categorization: group spending by category
    public Map<String, BigDecimal> getExpenseSummary(String accountNumber) {

        List<Transaction> transactions =
                transactionRepository.findByAccountNumberOrderByTimestampDesc(accountNumber);

        Map<String, BigDecimal> result = new HashMap<>();

        for (Transaction t : transactions) {

            if ("DEBIT".equals(t.getType())) {

                String category = t.getCategory();
                BigDecimal amount = t.getAmount();

                if (result.containsKey(category)) {
                    BigDecimal existing = result.get(category);
                    result.put(category, existing.add(amount));
                } else {
                    result.put(category, amount);
                }
            }
        }

        return result;
    }

public String formatTransactionSummary(String accountNumber) {
        List<Transaction> list = getRecentTransaction(accountNumber);
        if(list.isEmpty()) return "No recent transactions found.";

        StringBuilder sb= new StringBuilder(("Your last "+list.size() + "transactions:\n"));
        for(Transaction t : list) {
            sb.append(String.format("%s ₹%.2f - %s (%s)\\n",
                    t.getType(), t.getAmount(), t.getDescription(), t.getCategory()));
        }
        return sb.toString();

}
}
 