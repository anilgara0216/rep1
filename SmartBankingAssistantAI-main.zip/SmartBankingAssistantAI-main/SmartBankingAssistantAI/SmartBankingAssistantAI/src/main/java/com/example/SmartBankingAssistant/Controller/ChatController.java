package com.example.SmartBankingAssistant.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SmartBankingAssistant.AIChatService.BankingChatService;
import com.example.SmartBankingAssistant.DTOs.ChatRequest;
import com.example.SmartBankingAssistant.DTOs.ChatResponse;

import io.swagger.v3.oas.annotations.parameters.RequestBody;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/chat")
@CrossOrigin(origins = "*")
@RequiredArgsConstructor
public class ChatController {
	@Autowired
    private  BankingChatService bankingChatService = new BankingChatService();

    @PostMapping
    public ResponseEntity<ChatResponse> chat(@RequestBody ChatRequest request) {
        try {
            return ResponseEntity.ok(
                    bankingChatService.processChat(request));
        } catch (Exception e) {
        	
        	return ResponseEntity.ok(
                    new ChatResponse(
                            "Sorry, I'm having trouble processing your request. Please try again.",
                            "ERROR"));
        }
    }
}