package com.example.SmartBankingAssistant;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SmartBankingAssistantAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SmartBankingAssistantAiApplication.class, args);
	}

}
