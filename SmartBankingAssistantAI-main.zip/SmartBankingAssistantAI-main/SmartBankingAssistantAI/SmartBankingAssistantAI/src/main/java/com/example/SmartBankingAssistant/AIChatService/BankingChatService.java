package com.example.SmartBankingAssistant.AIChatService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.example.SmartBankingAssistant.DTOs.ChatRequest;
import com.example.SmartBankingAssistant.DTOs.ChatResponse;
import com.example.SmartBankingAssistant.Service.AccountService;
import com.example.SmartBankingAssistant.Service.FraudDetectionService;
import com.example.SmartBankingAssistant.Service.TransactionService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

@Service
public class BankingChatService {

    @Value("${openai.api.key}")
    private String openAiKey;

    @Value("${openai.api.url}")
    private String openAiUrl;
    
    @Autowired
    private AccountService accountService;
    private TransactionService transactionService;
    private FraudDetectionService fraudDetectionService;

    private final OkHttpClient client = new OkHttpClient();
    private final ObjectMapper mapper = new ObjectMapper();

    public ChatResponse processChat(ChatRequest request) throws Exception {

        String message = request.getMessage().toLowerCase();
        String account = request.getAccountNumber();

        String intent = detectIntent(message);
        String context = buildContext(intent, account);
        String reply = callAI(buildPrompt(context), request.getMessage());

        return new ChatResponse(reply, intent);
    }

    /* ---------------- Intent Detection ---------------- */

    private String detectIntent(String message) {

        if (message.contains("balance") || message.contains("money")) {
            return "BALANCE";
        }

        if (message.contains("transaction") || message.contains("history") || message.contains("spent")) {
            return "TRANSACTIONS";
        }

        if (message.contains("fraud") || message.contains("suspicious") || message.contains("alert")) {
            return "FRAUD";
        }

        if (message.contains("expense") || message.contains("category")) {
            return "EXPENSE";
        }

        if (message.contains("advice") || message.contains("save") || message.contains("invest") || message.contains("tip")) {
            return "ADVICE";
        }

        return "GENERAL";
    }

    /* ---------------- Context Builder ---------------- */

    private String buildContext(String intent, String account) {

        if ("BALANCE".equals(intent)) {
            return accountService.getBalance(account);
        }

        if ("TRANSACTIONS".equals(intent)) {
            return transactionService.formatTransactionSummary(account);
        }

        if ("FRAUD".equals(intent)) {
            return String.join("\n",
                    fraudDetectionService.detectFraud(account));
        }

        if ("EXPENSE".equals(intent)) {
            return "Expense breakdown: "
                    + transactionService.getExpenseSummary(account);
        }

        return "User account: " + account;
    }

    /* ---------------- Prompt ---------------- */

    private String buildPrompt(String context) {
        return "You are a smart banking assistant for an Indian bank.\n"
                + "Be polite, concise and helpful.\n"
                + "Always use ₹ for currency.\n\n"
                + "User data:\n"
                + context;
    }

    /* ---------------- OpenAI Call ---------------- */

    private String callAI(String systemPrompt, String userMessage)
            throws Exception {

        ObjectNode body = mapper.createObjectNode();
        body.put("model", "gpt-3.5-turbo");
        body.put("max_tokens", 500);

        ArrayNode messages = body.putArray("messages");

        ObjectNode systemMsg = mapper.createObjectNode();
        systemMsg.put("role", "system");
        systemMsg.put("content", systemPrompt);

        ObjectNode userMsg = mapper.createObjectNode();
        userMsg.put("role", "user");
        userMsg.put("content", userMessage);

        messages.add(systemMsg);
        messages.add(userMsg);

        Request request = new Request.Builder()
                .url(openAiUrl)
                .header("Authorization", "Bearer " + openAiKey)
                .header("Content-Type", "application/json")
                .post(RequestBody.create(
                        mapper.writeValueAsString(body),
                        MediaType.parse("application/json")))
                .build();

        try (Response response = client.newCall(request).execute()) {
            JsonNode json = mapper.readTree(response.body().string());
            return json.path("choices")
                    .get(0)
                    .path("message")
                    .path("content")
                    .asText();
        }
    }
} 