package com.example.SmartBankingAssistant.Service;


import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.SmartBankingAssistant.Model.Transaction;
import com.example.SmartBankingAssistant.Repository.TransactionRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FraudDetectionService {
	@Autowired
    private TransactionRepository transactionRepository;

    //simple rile-based fraud detection
    public List<String> detectFraud(String accountNumber) {
        List<Transaction>transactions = transactionRepository
                .findByAccountNumberOrderByTimestampDesc(accountNumber);

        List<String> alerts = new ArrayList<>();
        for(Transaction t :  transactions){
            //Rule 1: Large transaction > ₹50,000
            if (t.getAmount().compareTo(new BigDecimal("50000"))>0){
                alerts.add("Large transaction detected: ₹" + t.getAmount()
                + " for " + t.getDescription());
            }
            //Rule 2: Already flagged in DB
            if(t.isFlaggedFraud()){
                alerts.add("Suspicious transaction flagged: ₹" + t.getAmount()
                +" - "+t.getDescription());
            }
        }
        if(alerts.isEmpty()){
            alerts.add("No suspicious activity detected on your account.");
        }
        return alerts;
    }

}
 