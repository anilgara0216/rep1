package com.example.SmartBankingAssistant.Model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity //@Entity tells JPA/Hibernate that this class should be mapped to a database table
@Data
// Lombok annotation: Automatically generates getters, setters,
// toString(), equals(), and hashCode() methods
@NoArgsConstructor // Lombok annotation: Generates a no-argument constructor
@AllArgsConstructor // Lombok annotation: Generates a constructor with all fields as parameters
@Builder
// Lombok annotation: Enables the Builder design pattern
// Useful for creating objects in a clean and readable way

public class Transaction {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;
    private BigDecimal amount;
    private String type;
    public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Transaction(Long id, String accountNumber, BigDecimal amount, String type, String description,
			String category, LocalDateTime timestamp, boolean flaggedFraud) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		this.amount = amount;
		this.type = type;
		this.description = description;
		this.category = category;
		this.timestamp = timestamp;
		this.flaggedFraud = flaggedFraud;
	}
	@Override
	public String toString() {
		return "Transaction [id=" + id + ", accountNumber=" + accountNumber + ", amount=" + amount + ", type=" + type
				+ ", description=" + description + ", category=" + category + ", timestamp=" + timestamp
				+ ", flaggedFraud=" + flaggedFraud + "]";
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public LocalDateTime getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(LocalDateTime timestamp) {
		this.timestamp = timestamp;
	}
	public boolean isFlaggedFraud() {
		return flaggedFraud;
	}
	public void setFlaggedFraud(boolean flaggedFraud) {
		this.flaggedFraud = flaggedFraud;
	}
	// Type of transaction
    // Example values: "DEPOSIT", "WITHDRAWAL", "TRANSFER"
    private String description;
    // Description of the transaction
    // Example: "ATM withdrawal", "Salary credited"
    private String category;
    // Category of the transaction
    // Example: "FOOD", "RENT", "SHOPPING", "UTILITIES"
    private LocalDateTime timestamp;
    private boolean flaggedFraud;
    // Indicates whether the transaction is flagged as suspicious or fraudulent
    // true  : possible fraud
    // false : normal transaction

}
