package com.example.SmartBankingAssistant.Controller;

import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.SmartBankingAssistant.Service.AccountService;
import com.example.SmartBankingAssistant.Service.FraudDetectionService;

import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/accounts")
@RequiredArgsConstructor
@CrossOrigin(origins ="*")

public class AccountController {
    private final AccountService accountService = new AccountService();
    private final FraudDetectionService fraudDetectionService = new FraudDetectionService();

    @GetMapping("{accountNumber}/balance")
    public ResponseEntity<Map<String, Object>> getBalance(@PathVariable String accountNumber) {
        return ResponseEntity.ok(accountService.getAccountDetails(accountNumber));
    }
    @GetMapping("/{accountNumber}/fraud-alerts")
    public ResponseEntity<List<String>> getFraudAlerts(
            @PathVariable String accountNumber) {
        return ResponseEntity.ok(fraudDetectionService.detectFraud(accountNumber));

    }
}
