package com.example.SmartBankingAssistant.DTOs;

import lombok.Data;

@Data
public class ChatRequest {
    private String accountNumber;// Used to fetch account details or transaction history
    private String message; //show my recent transaction
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getMessage() {
		return message;
	}
	@Override
	public String toString() {
		return "ChatRequest [accountNumber=" + accountNumber + ", message=" + message + "]";
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public ChatRequest(String accountNumber, String message) {
		super();
		this.accountNumber = accountNumber;
		this.message = message;
	}
    
}
 