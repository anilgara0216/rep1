package com.example.SmartBankingAssistant.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatMessage {
    private String role;
    // "user" : message sent by the user
    // "assistant" : message sent by the AI/system
    private String content;
    // The actual content/text of the chat message
    // Example: "Hello, how can I help you?"
	public String getRole() {
		return role;
	}
	public ChatMessage(String role, String content) {
		super();
		this.role = role;
		this.content = content;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public String getContent() {
		return content;
	}
	@Override
	public String toString() {
		return "ChatMessage [role=" + role + ", content=" + content + "]";
	}
	public void setContent(String content) {
		this.content = content;
	}

}