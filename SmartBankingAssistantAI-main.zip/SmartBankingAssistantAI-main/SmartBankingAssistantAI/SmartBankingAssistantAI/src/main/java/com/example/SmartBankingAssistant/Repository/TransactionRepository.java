package com.example.SmartBankingAssistant.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SmartBankingAssistant.Model.Transaction;


public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    List<Transaction> findByAccountNumberOrderByTimestampDesc(String accountNumber);
    List<Transaction> findByAccountNumberAndCategory(String accountNumber, String category);
    List<Transaction> findByAccountNumberAndFlaggedFraudTrue(String accountNumber);
}