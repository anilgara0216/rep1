package com.example.SmartBankingAssistant.DTOs;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ChatResponse {
    private String reply;
    private String intent; //Balance, Transactions, Fraud, Advice
	public ChatResponse() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ChatResponse(String reply, String intent) {
		super();
		this.reply = reply;
		this.intent = intent;
	}
    
    
    
}
