package com.example.SmartBankingAssistant.Model;

import java.math.BigDecimal;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Account {
    public Account(Long id, String accountNumber, String ownerName, BigDecimal balance, String accountType) {
		super();
		this.id = id;
		this.accountNumber = accountNumber;
		OwnerName = ownerName;
		this.balance = balance;
		this.accountType = accountType;
	}
	@Id //@Id marks this field as the primary key of the table
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // @GeneratedValue tells JPA to automatically generate the ID value
    private Long id;
    // Unique account number for the bank account (e.g., ACC12345
    private String accountNumber;
    private String OwnerName;
    private BigDecimal balance;
    private String accountType;   //SAVINGS, CURRENT
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", accountNumber=" + accountNumber + ", OwnerName=" + OwnerName + ", balance="
				+ balance + ", accountType=" + accountType + "]";
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getOwnerName() {
		return OwnerName;
	}
	public void setOwnerName(String ownerName) {
		OwnerName = ownerName;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


}