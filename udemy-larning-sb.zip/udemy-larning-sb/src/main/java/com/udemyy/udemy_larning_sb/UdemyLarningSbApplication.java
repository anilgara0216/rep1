package com.udemyy.udemy_larning_sb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UdemyLarningSbApplication {

	public static void main(String[] args) {
		SpringApplication.run(UdemyLarningSbApplication.class, args);
	}

}
